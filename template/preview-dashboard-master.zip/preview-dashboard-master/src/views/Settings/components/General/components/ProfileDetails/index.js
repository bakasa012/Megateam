export { default } from './ProfileDetails';
