export { default } from './ProjectDetails';
