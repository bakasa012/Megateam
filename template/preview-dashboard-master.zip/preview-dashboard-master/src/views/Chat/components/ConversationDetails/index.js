export { default } from './ConversationDetails';
